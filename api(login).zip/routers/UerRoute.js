const router = require('express').Router();
const userController = require('../controller/UserController');

router.post('/registration', userController.register);
router.post('/login', userController.login);
router.get('/getuser', userController.userdata);
router.put('/updateuser', userController.updateUser);


module.exports = router;

const mongoose = require('mongoose');
const db = require("../config/db")
const bcrypt = require('bcrypt')

const { Schema } = mongoose;

const UserSchema = new Schema({
    email: {
        type: String,
        lowercase: true,
        required: true,
        unique: true

    }, password: {
        type: String,
        required: true
    }, name: {
        type: String,
        required: true
    }, phone_num: {
        type: String,
        required: true
    }, country: {
        type: String,
        required: true
    },
    img: {
        data: Buffer,
        contentType: String
    },
    dob: {
        type: String
    },
    sex: {
        type: String
    }

})

UserSchema.pre('save', async function (next) {
    try {
        var user = this
        if (!user.isModified('password')) {
            return next();
        }
        const salt = await bcrypt.genSalt(10);
        const hashpass = await bcrypt.hash(user.password, salt)
        user.password = hashpass
        next();
    } catch (error) {
        next(error);
    }
})


UserSchema.methods.comparePassword = async function (userPassword) {
    try {
        const isMatch = await bcrypt.compare(userPassword, this.password)
        return isMatch
    } catch (error) {
        throw error;
    }
}
const UserModel = db.model('user', UserSchema);
module.exports = UserModel;
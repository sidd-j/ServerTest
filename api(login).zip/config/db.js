const mongoose = require('mongoose')

const connection = mongoose.createConnection(process.env.MONGO_URL).on('open', () => {
    console.log("connected to database")
}).on('error', () => {
    console.log("Error Occured")
});
module.exports = connection
const { response } = require('../app');
const UserService = require('../services/UserServices')

exports.register = async (req, res, next) => {
    try {
        const { email, password, name, phone_num, country } = req.body;
        const successRes = await UserService.registerUser(email, password, name, phone_num, country);
        res.json({ status: true, success: 'User registered successfully' });
    } catch (error) {
        if (error.code === 11000 && error.keyPattern && error.keyPattern.email) {
            res.status(400).json({ status: false, error: 'Email already exists' });
        } else {
            res.status(500).json({ status: false, error: 'Failed to register user' });
        }
    }
}

exports.userdata = async (req, res, next) => {
    try {
        const { email } = req.query; // Extract email from query parameters
        const user = await UserService.getUserDataByEmail(email); // Fetch user data
        if (!user) {
            return res.status(404).json({ status: false, error: 'User not found : ${email}' });
        }
        res.json({ status: true, data: user }); // Return user data if found
    } catch (error) {
        console.error('Error fetching user data: ${email}', error);
        res.status(500).json({ status: false, error: 'Failed to fetch user data : ${email}' });
    }
};
exports.updateUser = async (req, res, next) => {
    try {
        const { email, ...updateFields } = req.body;
        const updatedUser = await UserService.getupdateUser(email, updateFields);
        if (!updatedUser) {
            return res.status(404).json({ status: false, error: `User not found: ${email}` });
        }
        res.json({ status: true, data: updatedUser });
    } catch (error) {
        console.error(`Failed to update user info: ${req.body.email}`, error);
        res.status(500).json({ status: false, error: `Failed to update user info: ${req.body.email}` });
    }
};



exports.login = async (req, res, next) => {
    try {
        const { email, password } = req.body;
        const user = await UserService.checkUser(email)
        if (!user) {
            return res.status(401).json({ status: false, error: 'User Does not exist' });
        }
        const isMatch = await user.comparePassword(password)

        if (!isMatch) {
            return res.status(401).json({ status: false, error: "Password Invalid!!!" });
        }

        let tokenData = { _id: user._id.toString(), email: user.email };

        const token = await UserService.generateToken(tokenData, "1234", '1hr')

        res.status(200).json({ status: true, token: token })
    } catch (error) {
        res.status(500).json({ status: false, error: 'An error occurred' });
    }
}

exports.logout = async (req, res, next) => {
    try {
        res.clearCookie('token');

        // Respond with a success message
        res.status(200).json({ status: true, message: 'Logged out successfully' });
    } catch (error) {
        res.status(500).json({ status: false, error: 'An error occurred' });
    }
}

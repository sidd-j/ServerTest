const UserModel = require('../model/User.model');
const jwt = require('jsonwebtoken');

class UserServices {
    static async registerUser(email, password, name, phone_num, country, dob) {
        try {
            const createUser = new UserModel({ email, password, name, phone_num, country, dob });
            return await createUser.save();
        } catch (err) {
            throw err;
        }
    }

    static async getUserDataByEmail(email) {
        try {
            return await UserModel.findOne({ email });
        } catch (err) {
            throw err;
        }
    }
    static async getupdateUser(email, updateFields) {
        try {
            const updateObject = {};
            for (const key in updateFields) {
                updateObject[key] = updateFields[key];
            }
            return await UserModel.findOneAndUpdate({ email }, { $set: updateObject }, { new: true });
        } catch (err) {
            throw err;
        }
    }


    static async checkUser(email) {
        try {
            return await UserModel.findOne({ email });
        } catch (err) {
            throw err;
        }
    }

    static async generateToken(tokenData, secretKey, jwt_expire) {
        return jwt.sign(tokenData, secretKey, { expiresIn: jwt_expire });
    }
}

module.exports = UserServices;
